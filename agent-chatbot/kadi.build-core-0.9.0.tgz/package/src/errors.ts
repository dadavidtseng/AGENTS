/**
 * Error handling for kadi-core v0.1.0
 *
 * All errors in kadi-core use KadiError, which includes:
 * - A human-readable message
 * - An error code for programmatic handling
 * - Context with additional details
 * - Automatic formatting of hints and suggestions
 *
 * The goal is helpful errors that guide users to solutions.
 */

// ═══════════════════════════════════════════════════════════════════════
// ERROR CODES
// ═══════════════════════════════════════════════════════════════════════

/**
 * All possible error codes.
 * Use these for programmatic error handling.
 *
 * @example
 * ```typescript
 * try {
 *   await client.connect();
 * } catch (error) {
 *   if (error instanceof KadiError && error.code === 'CONNECTION_FAILED') {
 *     // Handle connection failure specifically
 *   }
 * }
 * ```
 */
export type ErrorCode =
  // Connection errors
  | 'CONNECTION_FAILED'
  | 'AUTHENTICATION_FAILED'
  | 'REGISTRATION_FAILED'
  | 'BROKER_NOT_CONNECTED'
  | 'BROKER_CONNECTION_FAILED'
  | 'CONNECTION_CLOSED'

  // Broker errors
  | 'BROKER_ERROR'
  | 'BROKER_TIMEOUT'
  | 'BROKER_RESPONSE_ERROR'
  | 'UNKNOWN_BROKER'

  // Tool errors
  | 'TOOL_NOT_FOUND'
  | 'TOOL_ALREADY_REGISTERED'
  | 'TOOL_INVOCATION_FAILED'
  | 'TOOL_TIMEOUT'
  | 'VALIDATION_FAILED'

  // Ability errors
  | 'ABILITY_NOT_FOUND'
  | 'ABILITY_LOAD_FAILED'
  | 'ABILITY_NOT_CONNECTED'

  // Lock file errors
  | 'LOCKFILE_NOT_FOUND'
  | 'LOCKFILE_PARSE_ERROR'

  // Config errors
  | 'INVALID_CONFIG'
  | 'INVALID_INPUT'
  | 'PROJECT_ROOT_NOT_FOUND'

  // Transport errors
  | 'STDIO_ERROR'
  | 'STDIO_PROCESS_FAILED'
  | 'NATIVE_IMPORT_ERROR'
  | 'TRANSPORT_SEND_FAILED'

  // Secrets errors (Trusted Introducer pattern)
  | 'SECRETS_NOT_CONNECTED'
  | 'SECRETS_DECRYPTION_FAILED'
  | 'SECRETS_REQUEST_FAILED'
  | 'SECRETS_REJECTED'
  | 'SECRETS_TIMEOUT'

  // Generic
  | 'TIMEOUT'
  | 'INTERNAL_ERROR'
  | 'UNKNOWN_ERROR'
  | 'NOT_IMPLEMENTED';

// ═══════════════════════════════════════════════════════════════════════
// ERROR CONTEXT
// ═══════════════════════════════════════════════════════════════════════

/**
 * Additional context that can be attached to errors.
 * All fields are optional - include what's helpful.
 */
export interface ErrorContext {
  /** Hint for how to fix the error */
  hint?: string;

  /** Alternative approaches */
  alternative?: string;

  /** Path that was searched */
  searched?: string;

  /** List of available options */
  available?: string[];

  /** List of connected brokers */
  connectedBrokers?: string[];

  /** The broker name involved */
  broker?: string;

  /** The broker URL involved */
  url?: string;

  /** The tool name involved */
  toolName?: string;

  /** The ability name involved */
  abilityName?: string;

  /** The path involved */
  path?: string;

  /** The reason for the error */
  reason?: string;

  /** Any other context */
  [key: string]: unknown;
}

// ═══════════════════════════════════════════════════════════════════════
// KADI ERROR CLASS
// ═══════════════════════════════════════════════════════════════════════

/**
 * Custom error class for kadi-core.
 *
 * Features:
 * - Error code for programmatic handling
 * - Context object with additional details
 * - Automatic formatting of helpful messages
 *
 * @example
 * ```typescript
 * throw new KadiError(
 *   'Ability "calculator" not found in agent-lock.json',
 *   'ABILITY_NOT_FOUND',
 *   {
 *     searched: '/path/to/agent-lock.json',
 *     hint: 'Run `kadi install calculator` to install it',
 *     alternative: 'Or specify explicit path: { path: "./path" }',
 *   }
 * );
 * ```
 */
export class KadiError extends Error {
  /**
   * Error code for programmatic handling.
   */
  public readonly code: ErrorCode;

  /**
   * Additional context about the error.
   */
  public readonly context: ErrorContext;

  constructor(message: string, code: ErrorCode, context: ErrorContext = {}) {
    // Format the message with context appended
    super(formatErrorMessage(message, context));

    this.name = 'KadiError';
    this.code = code;
    this.context = context;

    // Maintain proper stack trace in V8 environments
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, KadiError);
    }
  }

  /**
   * Create a KadiError from an unknown error.
   * Useful for wrapping errors from external sources.
   *
   * @param error - The error to wrap
   * @param code - Error code to use (default: 'UNKNOWN_ERROR')
   * @param context - Additional context to add
   */
  static from(
    error: unknown,
    code: ErrorCode = 'UNKNOWN_ERROR',
    context: ErrorContext = {}
  ): KadiError {
    // If it's already a KadiError, return it (don't double-wrap)
    if (error instanceof KadiError) {
      return error;
    }

    // Extract message from various error types
    let message: string;
    if (error instanceof Error) {
      message = error.message;
    } else if (typeof error === 'string') {
      message = error;
    } else {
      message = 'An unknown error occurred';
    }

    return new KadiError(message, code, context);
  }

  /**
   * Check if an error is a KadiError.
   */
  static isKadiError(error: unknown): error is KadiError {
    return error instanceof KadiError;
  }
}

// ═══════════════════════════════════════════════════════════════════════
// MESSAGE FORMATTING
// ═══════════════════════════════════════════════════════════════════════

/**
 * Format an error message with context appended.
 * Creates a multi-line message that's easy to read in console output.
 *
 * @example
 * Input:
 *   message: 'Ability "foo" not found'
 *   context: { searched: '/path', hint: 'Run kadi install foo' }
 *
 * Output:
 *   'Ability "foo" not found
 *     Searched: /path
 *     Hint: Run kadi install foo'
 */
function formatErrorMessage(message: string, context: ErrorContext): string {
  const lines: string[] = [message];

  // Add context fields in a consistent order
  if (context.searched) {
    lines.push(`  Searched: ${context.searched}`);
  }

  if (context.path) {
    lines.push(`  Path: ${context.path}`);
  }

  if (context.broker) {
    lines.push(`  Broker: ${context.broker}`);
  }

  if (context.url) {
    lines.push(`  URL: ${context.url}`);
  }

  if (context.reason) {
    lines.push(`  Reason: ${context.reason}`);
  }

  if (context.connectedBrokers && context.connectedBrokers.length > 0) {
    lines.push(`  Connected brokers: ${context.connectedBrokers.join(', ')}`);
  }

  if (context.available && context.available.length > 0) {
    lines.push(`  Available: ${context.available.join(', ')}`);
  }

  if (context.hint) {
    lines.push(`  Hint: ${context.hint}`);
  }

  if (context.alternative) {
    lines.push(`  Or: ${context.alternative}`);
  }

  return lines.join('\n');
}

// ═══════════════════════════════════════════════════════════════════════
// TYPE GUARD
// ═══════════════════════════════════════════════════════════════════════

/**
 * Check if a value is an Error object.
 */
export function isError(value: unknown): value is Error {
  return value instanceof Error;
}
