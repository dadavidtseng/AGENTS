/**
 * kadi-core v0.1.0
 *
 * A lean, readable SDK for building KADI agents.
 *
 * @example
 * ```typescript
 * import { KadiClient, z } from 'kadi-core';
 *
 * const client = new KadiClient({
 *   name: 'my-agent',
 *   brokers: {
 *     production: { url: 'ws://broker:8080/kadi' },
 *   },
 *   defaultBroker: 'production',
 * });
 *
 * client.registerTool({
 *   name: 'add',
 *   description: 'Add two numbers',
 *   input: z.object({ a: z.number(), b: z.number() }),
 * }, async ({ a, b }) => ({ result: a + b }));
 *
 * await client.connect();
 * ```
 */

// Re-export Zod for schema definitions
export { z } from 'zod';

// Main client
export { KadiClient } from './client.js';

// Errors
export { KadiError } from './errors.js';
export type { ErrorCode, ErrorContext } from './errors.js';

// Types
export type {
  // Configuration
  ClientConfig,
  BrokerEntry,
  ResolvedConfig,

  // Tools
  ToolDefinition,
  BrokerToolDefinition,
  ZodToolDefinition,
  ToolHandler,
  RegisteredTool,
  JSONSchema,
  RequestContext,

  // Abilities
  LoadedAbility,
  InvokeOptions,
  TransportType,
  EventHandler,

  // Options
  RegisterToolOptions,
  LoadOptions,
  LoadNativeOptions,
  LoadStdioOptions,
  LoadBrokerOptions,
  InvokeRemoteOptions,

  // Broker
  BrokerState,
  BrokerStatus,
  PendingRequest,
  PendingInvocation,

  // Broker Events (Pub/Sub)
  BrokerEvent,
  BrokerEventHandler,
  PublishOptions,
  SubscribeOptions,
  EmitOptions,

  // JSON-RPC
  JsonRpcRequest,
  JsonRpcResponse,
  JsonRpcNotification,
  JsonRpcError,
  JsonRpcMessage,

  // Lock file
  AgentLockFile,
  AbilityLockEntry,

  // Script resolution
  ResolvedScript,
} from './types.js';

// Zod utilities
export { zodToJsonSchema, isZodSchema } from './zod.js';

// Lock file utilities
export {
  findProjectRoot,
  readLockFile,
  findAbilityEntry,
  resolveAbilityPath,
  resolveAbilityEntry,
  getInstalledAbilityNames,
} from './lockfile.js';

// Transports (for advanced use cases)
export { loadNativeTransport } from './transports/native.js';
export { loadStdioTransport } from './transports/stdio.js';
export { loadBrokerTransport } from './transports/broker.js';
export type { BrokerTransportOptions } from './transports/broker.js';

// Protocol message builders
export * as protocol from './protocol.js';

// Crypto utilities (Ed25519 to X25519 conversion)
export { convertToEncryptionKey, convertToEncryptionKeyPair } from './crypto.js';
export type { EncryptionKeyPair } from './crypto.js';
