/**
 * Stdio transport for kadi-core v0.1.0
 *
 * Loads abilities that run as CHILD PROCESSES.
 * Communication happens via stdin/stdout using JSON-RPC with Content-Length framing.
 *
 * Protocol (same as LSP - Language Server Protocol):
 * - Each message is prefixed with "Content-Length: <bytes>\r\n\r\n"
 * - The content is JSON (JSON-RPC 2.0 format)
 *
 * This transport is language-agnostic - the child process can be Python, Go, etc.
 * as long as it speaks the same protocol.
 *
 * How it works:
 * 1. Spawn the child process
 * 2. Send "readAgentJson" to get tool definitions
 * 3. For each invoke(), send request and wait for response
 * 4. On disconnect, send "shutdown" and kill the process
 */

import { spawn, type ChildProcess } from 'child_process';
import type { Readable, Writable } from 'stream';
import { z } from 'zod';
import type { LoadedAbility, InvokeOptions, ToolDefinition, JsonRpcRequest, JsonRpcResponse, EventHandler } from '../types.js';
import { KadiError } from '../errors.js';
import * as protocol from '../protocol.js';

/** Schema for event notification params */
const EventNotificationParams = z.object({
  name: z.string(),
  data: z.unknown(),
});

/**
 * JSON-RPC notification (no id field).
 */
interface JsonRpcNotification {
  jsonrpc: '2.0';
  method: string;
  params?: unknown;
}

// ═══════════════════════════════════════════════════════════════════════════════
// MESSAGE READER (Content-Length framing)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Reads JSON-RPC messages from a stream using Content-Length framing.
 *
 * Uses Buffer (not string) for binary safety. Handles partial messages
 * across chunks and recovers from malformed headers.
 *
 * Message format:
 * ```
 * Content-Length: 42\r\n
 * \r\n
 * {"jsonrpc":"2.0","id":1,"result":{...}}
 * ```
 */
class StdioReader {
  private buffer = Buffer.alloc(0);
  private static readonly HEADER_END = '\r\n\r\n';
  private static readonly HEADER_END_LENGTH = 4; // \r\n\r\n
  private static readonly CONTENT_LENGTH_MARKER = Buffer.from('Content-Length:');
  private static readonly CONTENT_LENGTH_PATTERN = /Content-Length:\s*(\d+)/;

  private waiters: Array<{
    id: string | number;
    resolve: (response: JsonRpcResponse) => void;
    reject: (error: Error) => void;
    timeout: ReturnType<typeof setTimeout>;
  }> = [];

  /** Handler for event notifications */
  private notificationHandler: ((notification: JsonRpcNotification) => void) | null = null;

  constructor(stream: Readable, private timeoutMs: number = 600000) {
    stream.on('data', (chunk: Buffer) => this.onData(chunk));
  }

  /**
   * Set handler for notifications (messages without id).
   */
  setNotificationHandler(handler: (notification: JsonRpcNotification) => void): void {
    this.notificationHandler = handler;
  }

  /**
   * Handle incoming data from the stream.
   */
  private onData(chunk: Buffer): void {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    this.processBuffer();
  }

  /**
   * Process the buffer, extracting complete messages.
   */
  private processBuffer(): void {
    let message: JsonRpcResponse | null;
    while ((message = this.tryReadSingleMessage()) !== null) {
      this.dispatchMessage(message);
    }
  }

  /**
   * Try to read a single complete message from the buffer.
   * @returns Parsed message, or null if no complete message available
   */
  private tryReadSingleMessage(): JsonRpcResponse | null {
    // Look for header end marker
    const headerEndIndex = this.buffer.indexOf(StdioReader.HEADER_END);
    if (headerEndIndex === -1) {
      return null; // No complete header yet
    }

    // Parse Content-Length from header
    const header = this.buffer.slice(0, headerEndIndex).toString('utf8');
    const match = header.match(StdioReader.CONTENT_LENGTH_PATTERN);
    if (!match?.[1]) {
      // Invalid header - skip to next potential header
      this.skipToNextHeader();
      return null;
    }

    const contentLength = parseInt(match[1], 10);
    const contentStart = headerEndIndex + StdioReader.HEADER_END_LENGTH;
    const contentEnd = contentStart + contentLength;

    // Check if we have the complete message
    if (this.buffer.length < contentEnd) {
      return null; // Need more data
    }

    // Extract and parse JSON
    const content = this.buffer.slice(contentStart, contentEnd).toString('utf8');
    this.buffer = this.buffer.slice(contentEnd); // Remove processed data

    try {
      return JSON.parse(content) as JsonRpcResponse;
    } catch (error) {
      // Invalid JSON - log error so developer knows something's wrong
      console.error('[KADI] Failed to parse message from child process:', error);
      console.error('[KADI] Raw content (truncated):', content.slice(0, 200));
      return null;
    }
  }

  /**
   * Skip to next potential header (error recovery).
   * Called when we encounter a malformed header.
   */
  private skipToNextHeader(): void {
    const nextHeaderIndex = this.buffer.indexOf(StdioReader.CONTENT_LENGTH_MARKER, 1);

    if (nextHeaderIndex === -1) {
      this.buffer = Buffer.alloc(0); // No more headers, clear buffer
    } else {
      this.buffer = this.buffer.slice(nextHeaderIndex);
    }
  }

  /**
   * Dispatch a parsed message to waiting handlers or notification handler.
   */
  private dispatchMessage(message: JsonRpcResponse | JsonRpcNotification): void {
    // Check if this is a notification (no id field)
    if (!('id' in message) || message.id === undefined) {
      // It's a notification - route to notification handler
      if (this.notificationHandler) {
        this.notificationHandler(message as JsonRpcNotification);
      }
      return;
    }

    // It's a response - find and remove waiter for this message id
    const waiterIndex = this.waiters.findIndex((w) => w.id === message.id);
    if (waiterIndex === -1) {
      return; // No one waiting for this response
    }

    // splice returns removed elements - use destructuring to get the waiter
    const [waiter] = this.waiters.splice(waiterIndex, 1);
    if (!waiter) {
      return;
    }

    clearTimeout(waiter.timeout);
    waiter.resolve(message);
  }

  /**
   * Wait for a response with a specific id.
   */
  waitForResponse(id: string | number, timeoutOverride?: number): Promise<JsonRpcResponse> {
    const effectiveTimeout = timeoutOverride ?? this.timeoutMs;
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        // Remove from waiters
        const index = this.waiters.findIndex((w) => w.id === id);
        if (index !== -1) {
          this.waiters.splice(index, 1);
        }
        reject(new KadiError(
          `Timeout waiting for response to request ${id}`,
          'TIMEOUT',
          { requestId: id, timeoutMs: effectiveTimeout }
        ));
      }, effectiveTimeout);

      this.waiters.push({ id, resolve, reject, timeout });
    });
  }

  /**
   * Cancel all pending waiters (for cleanup).
   * @param error - Optional error to reject with (defaults to generic close error)
   */
  cancelAll(error?: Error): void {
    const rejectError = error ?? new KadiError('Connection closed', 'STDIO_ERROR');
    for (const waiter of this.waiters) {
      clearTimeout(waiter.timeout);
      waiter.reject(rejectError);
    }
    this.waiters = [];
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// MESSAGE WRITER (Content-Length framing)
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Writes JSON-RPC messages to a stream using Content-Length framing.
 */
class StdioWriter {
  constructor(private stream: Writable) {}

  /**
   * Write a message to the stream.
   */
  write(message: JsonRpcRequest): void {
    const json = JSON.stringify(message);
    const contentLength = Buffer.byteLength(json, 'utf-8');
    const header = `Content-Length: ${contentLength}\r\n\r\n`;

    this.stream.write(header + json);
  }
}

// ═══════════════════════════════════════════════════════════════════════════════
// STDIO TRANSPORT
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * Agent JSON structure returned by readAgentJson.
 */
interface AgentJsonLike {
  name: string;
  tools?: ToolDefinition[];
}

/**
 * Load a child process ability via stdio.
 *
 * The child process must speak JSON-RPC over stdin/stdout with Content-Length framing.
 * This is the standard KADI ability protocol.
 *
 * @param command - Command to run (e.g., 'python3', 'node')
 * @param args - Arguments to pass to the command
 * @param options - Additional options
 * @returns LoadedAbility that can invoke tools
 *
 * @example
 * ```typescript
 * // Load a Python ability
 * const analyzer = await loadStdioTransport('python3', ['analyzer.py']);
 * const result = await analyzer.invoke('analyze', { text: 'hello' });
 *
 * // Load a Node.js ability
 * const calc = await loadStdioTransport('node', ['dist/index.js']);
 * ```
 */
export async function loadStdioTransport(
  command: string,
  args: string[] = [],
  options: { timeoutMs?: number; cwd?: string } = {}
): Promise<LoadedAbility> {
  const timeoutMs = options.timeoutMs ?? 600000; // 10 minutes default

  // Step 1: Spawn the child process
  let proc: ChildProcess;
  try {
    proc = spawn(command, args, {
      stdio: ['pipe', 'pipe', 'inherit'], // stdin, stdout, stderr
      cwd: options.cwd, // Working directory for the child process
    });
  } catch (error) {
    throw new KadiError(
      `Failed to spawn process: ${command}`,
      'STDIO_ERROR',
      {
        command,
        args,
        reason: error instanceof Error ? error.message : String(error),
        hint: 'Check that the command exists and is executable',
      }
    );
  }

  // Step 2: Set up reader and writer
  // IMPORTANT: Must do this BEFORE setting up event handlers that reference reader
  if (!proc.stdin || !proc.stdout) {
    proc.kill();
    throw new KadiError(
      'Failed to get stdio streams',
      'STDIO_ERROR',
      { command }
    );
  }

  const reader = new StdioReader(proc.stdout, timeoutMs);
  const writer = new StdioWriter(proc.stdin);
  let idCounter = 1;
  let isShutdown = false;

  // Track whether WE initiated the shutdown (vs process crashing)
  // This distinguishes graceful disconnect() from unexpected crashes
  let shutdownInitiated = false;

  // Track process errors to reject pending requests
  let processError: KadiError | null = null;

  // ─────────────────────────────────────────────────────────────────────────
  // PROCESS EVENT HANDLERS
  // These are set up AFTER reader exists so we can call reader.cancelAll()
  // ─────────────────────────────────────────────────────────────────────────

  // Handle spawn errors (e.g., command not found, permission denied)
  proc.on('error', (error) => {
    processError = new KadiError(
      `Process error: ${command}`,
      'STDIO_ERROR',
      {
        command,
        reason: error.message,
        hint: 'Check that the command exists and is executable',
      }
    );
    reader.cancelAll(processError);
  });

  // Handle process exit (crash detection)
  // This fires when the child process terminates for ANY reason:
  // - process.exit() called
  // - Uncaught exception
  // - Killed by signal
  // - Normal completion
  proc.on('exit', (code, signal) => {
    // Only treat as error if WE didn't initiate the shutdown
    // If shutdownInitiated is true, this is expected (we called disconnect())
    if (!shutdownInitiated) {
      // Build descriptive error message based on how process exited
      const message = signal
        ? `Child process killed by signal ${signal}`
        : `Child process exited with code ${code}`;

      processError = new KadiError(message, 'STDIO_ERROR', {
        command,
        exitCode: code,
        signal,
        hint: 'Check stderr output from the child process for details',
      });

      // Reject all pending requests immediately (no waiting for timeout)
      reader.cancelAll(processError);
    }

    // Mark as shutdown regardless (can't send more requests to dead process)
    isShutdown = true;
  });

  /**
   * Send a request and wait for response.
   */
  async function sendRequest(method: string, params: unknown, timeoutMs?: number): Promise<unknown> {
    if (isShutdown) {
      throw new KadiError('Connection is closed', 'STDIO_ERROR');
    }

    // Check if process has errored
    if (processError) {
      throw processError;
    }

    const id = idCounter++;
    const request = protocol.request(id, method, params);

    writer.write(request);
    const response = await reader.waitForResponse(id, timeoutMs);

    if (response.error) {
      throw new KadiError(
        response.error.message,
        'STDIO_ERROR',
        { code: response.error.code, data: response.error.data }
      );
    }

    return response.result;
  }

  // Step 3: Get agent information
  let agentJson: AgentJsonLike;
  try {
    agentJson = await sendRequest('readAgentJson', {}) as AgentJsonLike;
  } catch (error) {
    proc.kill();
    throw new KadiError(
      'Failed to get agent information from child process',
      'ABILITY_LOAD_FAILED',
      {
        command,
        args,
        reason: error instanceof Error ? error.message : String(error),
        hint: 'The child process must respond to "readAgentJson" requests',
      }
    );
  }

  // Step 4: Set up event handling
  const eventHandlers = new Map<string, Set<EventHandler>>();

  reader.setNotificationHandler((notification) => {
    // Only handle 'event' notifications
    if (notification.method !== 'event') {
      return;
    }

    // Validate params with Zod (consistent with rest of kadi-core)
    const parsed = EventNotificationParams.safeParse(notification.params);
    if (!parsed.success) {
      console.warn('[KADI] Ignoring malformed event notification:', parsed.error.format());
      return;
    }

    const { name: eventName, data: eventData } = parsed.data;

    const handlers = eventHandlers.get(eventName);
    if (handlers) {
      for (const handler of handlers) {
        Promise.resolve(handler(eventData)).catch((err) => {
          console.error(`[KADI] Event handler error for "${eventName}":`, err);
        });
      }
    }
  });

  // Step 5: Return LoadedAbility interface
  return {
    name: agentJson.name,
    transport: 'stdio',

    /**
     * Invoke a tool on this ability.
     * Sends a JSON-RPC request and waits for the response.
     *
     * @param toolName - Name of the tool to invoke
     * @param params - Input parameters for the tool
     * @param invokeOptions - Optional settings (timeout override)
     */
    async invoke<T>(toolName: string, params: unknown, invokeOptions?: InvokeOptions): Promise<T> {
      try {
        const result = await sendRequest('invoke', { toolName, toolInput: params }, invokeOptions?.timeout);
        return result as T;
      } catch (error) {
        if (error instanceof KadiError) {
          throw error;
        }
        throw new KadiError(
          `Tool "${toolName}" invocation failed`,
          'TOOL_INVOCATION_FAILED',
          {
            toolName,
            ability: agentJson.name,
            reason: error instanceof Error ? error.message : String(error),
          }
        );
      }
    },

    /**
     * Get the list of tools this ability provides.
     */
    getTools(): ToolDefinition[] {
      return agentJson.tools ?? [];
    },

    /**
     * Subscribe to events from this ability.
     */
    on(event: string, handler: EventHandler): void {
      let handlers = eventHandlers.get(event);
      if (!handlers) {
        handlers = new Set();
        eventHandlers.set(event, handlers);
      }
      handlers.add(handler);
    },

    /**
     * Unsubscribe from events.
     */
    off(event: string, handler: EventHandler): void {
      const handlers = eventHandlers.get(event);
      if (handlers) {
        handlers.delete(handler);
        if (handlers.size === 0) {
          eventHandlers.delete(event);
        }
      }
    },

    /**
     * Disconnect and cleanup.
     * Sends a shutdown request and kills the process.
     */
    async disconnect(): Promise<void> {
      if (isShutdown) {
        return;
      }

      // Clear event handlers
      eventHandlers.clear();

      // Mark that WE initiated shutdown BEFORE sending the request
      // This prevents the 'exit' handler from treating our graceful
      // shutdown as a crash (race condition: process might exit before
      // we set this flag if we waited until after sendRequest)
      shutdownInitiated = true;

      // Try to send shutdown gracefully
      // Note: sendRequest checks isShutdown, not shutdownInitiated,
      // so this will still work
      try {
        await sendRequest('shutdown', {});
      } catch {
        // Ignore errors during shutdown (process might have already exited)
      }

      isShutdown = true;

      // Cancel any pending requests (there shouldn't be any at this point,
      // but this ensures cleanup if something went wrong)
      reader.cancelAll();

      // Kill the process and wait for it to exit
      proc.kill('SIGTERM');

      // Wait for graceful termination, then force kill
      await new Promise<void>((resolve) => {
        const forceKillTimer = setTimeout(() => {
          if (!proc.killed) {
            proc.kill('SIGKILL');
          }
          resolve();
        }, 1000);

        proc.once('exit', () => {
          clearTimeout(forceKillTimer);
          resolve();
        });
      });
    },
  };
}
