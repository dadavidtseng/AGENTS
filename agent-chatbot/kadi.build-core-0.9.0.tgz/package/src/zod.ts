/**
 * Zod utilities for kadi-core v0.1.0
 *
 * Uses Zod 4's built-in JSON Schema conversion.
 * See: https://zod.dev/json-schema
 */

import { z, type ZodType } from 'zod';
import type { JSONSchema } from './types.js';

/**
 * Check if a value is a Zod schema.
 *
 * Uses duck-typing on the internal `_zod` property rather than `instanceof`
 * to handle cases where prototype chains are broken by bundlers (e.g., esbuild)
 * or when multiple Zod instances exist.
 */
export function isZodSchema(value: unknown): value is ZodType {
  if (value === null || typeof value !== 'object') {
    return false;
  }

  // All Zod 4 schemas have an internal _zod property
  if (!('_zod' in value)) {
    return false;
  }

  const zod = (value as { _zod: unknown })._zod;
  if (zod === null || typeof zod !== 'object') {
    return false;
  }

  // _zod.def holds the schema definition
  if (!('def' in zod)) {
    return false;
  }

  const def = (zod as { def: unknown }).def;
  if (def === null || typeof def !== 'object') {
    return false;
  }

  // def.type is the discriminator (e.g., "string", "object", "array")
  if (!('type' in def)) {
    return false;
  }

  return typeof (def as { type: unknown }).type === 'string';
}

/**
 * Convert a Zod schema to JSON Schema using Zod 4's built-in conversion.
 *
 * @param schema - Zod schema to convert
 * @returns JSON Schema equivalent
 *
 * @example
 * ```typescript
 * const inputSchema = z.object({
 *   text: z.string().describe('Text to analyze'),
 *   limit: z.number().optional().default(10),
 * });
 *
 * const jsonSchema = zodToJsonSchema(inputSchema);
 * ```
 */
export function zodToJsonSchema(schema: ZodType): JSONSchema {
  return z.toJSONSchema(schema);
}
