/**
 * Core type definitions for kadi-core v0.1.0
 *
 * This file contains ALL types used throughout the codebase.
 * Having types in one place makes them easy to find and understand.
 *
 * Organization:
 * 1. Configuration - ClientConfig and related
 * 2. Tools - Tool definitions and handlers
 * 3. Loaded Abilities - The interface for using abilities
 * 4. Broker State - Internal broker connection state
 * 5. JSON-RPC - Protocol message types
 * 6. Lock File - agent-lock.json structure
 */

import type { ZodType } from 'zod';
import type { JSONSchema as JSONSchemaTypes } from 'zod/v4/core';
import type { WebSocket } from 'ws';

/**
 * JSON Schema type from Zod 4.
 * This is what z.toJSONSchema() returns for a single schema.
 */
export type JSONSchema = JSONSchemaTypes.JSONSchema;

// ═══════════════════════════════════════════════════════════════════════
// 1. CONFIGURATION
// ═══════════════════════════════════════════════════════════════════════

/**
 * Per-broker connection configuration.
 *
 * Use this when different brokers should join different networks.
 *
 * @example
 * ```typescript
 * brokers: {
 *   local: { url: 'ws://localhost:8080/kadi', networks: ['private', 'public'] },
 *   remote: { url: 'wss://remote/kadi', networks: ['public'] },
 * }
 * ```
 */
export interface BrokerEntry {
  /** WebSocket URL for this broker */
  url: string;

  /**
   * Networks to join on this broker.
   * Defaults to `['global']` if omitted.
   */
  networks?: string[];
}

/**
 * Configuration options for creating a KadiClient.
 *
 * @example
 * ```typescript
 * const client = new KadiClient({
 *   name: 'my-agent',
 *   version: '1.0.0',
 *   brokers: {
 *     prod: { url: 'ws://broker-prod:8080/kadi', networks: ['public'] },
 *     internal: { url: 'ws://broker-internal:8080/kadi', networks: ['private'] },
 *   },
 *   defaultBroker: 'prod',
 * });
 * ```
 */
export interface ClientConfig {
  /** Name of this agent (required) */
  name: string;

  /** Version of this agent (default: '1.0.0') */
  version?: string;

  /** Description of what this agent does */
  description?: string;

  /**
   * Named brokers to connect to.
   * Keys are friendly names, values are BrokerEntry objects.
   *
   * @example
   * ```typescript
   * brokers: {
   *   local: { url: 'ws://localhost:8080/kadi', networks: ['private'] },
   *   remote: { url: 'wss://remote/kadi', networks: ['public'] },
   * }
   * ```
   */
  brokers?: Record<string, BrokerEntry>;

  /**
   * Which broker to use by default for invokeRemote() and loadBroker().
   * Must be a key from the brokers map.
   */
  defaultBroker?: string;

  /**
   * Heartbeat interval in milliseconds.
   * Broker expects heartbeats to stay connected.
   * Default: 25000 (25 seconds)
   */
  heartbeatInterval?: number;

  /**
   * Timeout for remote requests in milliseconds.
   * Default: 600000 (10 minutes)
   */
  requestTimeout?: number;

  /**
   * Automatically reconnect to broker if connection is lost.
   * Uses exponential backoff with jitter to prevent thundering herd.
   * Default: true
   */
  autoReconnect?: boolean;

  /**
   * Maximum delay between reconnection attempts in milliseconds.
   * Backoff doubles each attempt: 1s → 2s → 4s → ... → maxReconnectDelay
   * Default: 30000 (30 seconds)
   */
  maxReconnectDelay?: number;

  /**
   * Pre-existing Ed25519 identity to use instead of generating an ephemeral one.
   *
   * When provided, the client uses this keypair for authentication with all brokers.
   * This enables persistent identity across multiple client instances (e.g., CLI invocations).
   *
   * If not provided, a new ephemeral keypair is generated at construction time.
   *
   * @example
   * ```typescript
   * import crypto from 'node:crypto';
   *
   * // Generate once and persist
   * const { publicKey, privateKey } = crypto.generateKeyPairSync('ed25519');
   *
   * const client = new KadiClient({
   *   name: 'my-agent',
   *   identity: {
   *     privateKey: privateKey.export({ type: 'pkcs8', format: 'der' }),
   *     publicKey: publicKey.export({ type: 'spki', format: 'der' }).toString('base64'),
   *   },
   * });
   * ```
   */
  identity?: {
    /** Ed25519 private key in PKCS8 DER format */
    privateKey: Buffer;
    /** Base64-encoded Ed25519 public key in SPKI DER format */
    publicKey: string;
  };
}

/**
 * Resolved configuration with all defaults applied.
 * Internal use - users work with ClientConfig.
 */
export interface ResolvedConfig {
  name: string;
  version: string;
  description: string;
  /** Normalized broker configs. Each entry has a url and resolved networks array. */
  brokers: Record<string, { url: string; networks: string[] }>;
  defaultBroker: string | undefined;
  heartbeatInterval: number;
  requestTimeout: number;
  autoReconnect: boolean;
  maxReconnectDelay: number;
}

// ═══════════════════════════════════════════════════════════════════════
// 2. TOOLS
// ═══════════════════════════════════════════════════════════════════════

/**
 * Tool definition using JSON Schema (from Zod 4).
 * Prefer ZodToolDefinition for type safety.
 */
export interface ToolDefinition {
  /** Unique name for this tool */
  name: string;

  /** Human-readable description of what this tool does */
  description: string;

  /** JSON Schema for input parameters (must be type: 'object') */
  inputSchema: JSONSchema;

  /** JSON Schema for output (optional, must be type: 'object' if provided) */
  outputSchema?: JSONSchema;
}

/**
 * Tool definition extended with optional per-tool network scoping.
 * Used when sending tool definitions to brokers and in readAgentJson().
 */
export interface BrokerToolDefinition extends ToolDefinition {
  /** Networks this tool is visible on (omitted if visible on all client networks) */
  networks?: string[];
}

/**
 * Tool definition using Zod schemas.
 * Recommended approach - provides type inference.
 *
 * @example
 * ```typescript
 * client.registerTool({
 *   name: 'add',
 *   description: 'Add two numbers',
 *   input: z.object({ a: z.number(), b: z.number() }),
 *   output: z.object({ result: z.number() }),
 * }, async ({ a, b }) => ({ result: a + b }));
 * ```
 */
export interface ZodToolDefinition<TInput, TOutput> {
  /** Unique name for this tool */
  name: string;

  /** Human-readable description of what this tool does */
  description: string;

  /** Zod schema for input parameters */
  input: ZodType<TInput>;

  /** Zod schema for output (optional) */
  output?: ZodType<TOutput>;
}

/**
 * Context passed to tool handlers when invoked via broker.
 *
 * This provides information about the incoming request, allowing handlers to:
 * - Route subsequent calls to the correct broker
 * - Access caller identity for authorization
 * - Trace requests across services
 *
 * @example
 * ```typescript
 * client.registerTool({ name: 'register-model', ... }, async (input, ctx) => {
 *   // Store which broker the caller is on for later routing
 *   await registry.save({ ...input, sourceBroker: ctx?.broker });
 *
 *   // Make a call back to the same broker
 *   await client.invokeRemote('notify', data, { broker: ctx?.broker });
 * });
 * ```
 */
export interface RequestContext {
  /** Which broker this request came from */
  broker: string;

  /** Unique request ID for tracing/correlation */
  requestId: string;

  /** Which network the request came through */
  network?: string;

  /** Caller's protocol - affects response formatting ('mcp' or 'kadi') */
  callerProtocol?: 'mcp' | 'kadi';

  /** Caller's session ID (ephemeral, changes per connection) */
  callerSessionId?: string;

  /** Caller's public key (stable across reconnects, undefined if unauthenticated) */
  callerPublicKey?: string;
}

/**
 * Function that handles tool invocation.
 * Receives validated input and optional request context.
 *
 * The context parameter is provided when the tool is invoked via broker.
 * For local invocations (via native transport), context may be undefined.
 *
 * @example
 * ```typescript
 * // Simple handler - doesn't use context
 * async ({ a, b }) => ({ result: a + b })
 *
 * // Handler that uses context for routing
 * async (input, ctx) => {
 *   await client.invokeRemote('helper', data, { broker: ctx?.broker });
 *   return result;
 * }
 * ```
 */
export type ToolHandler<TInput = unknown, TOutput = unknown> = (
  input: TInput,
  context?: RequestContext
) => Promise<TOutput>;

/**
 * A tool that has been registered with the client.
 * Internal use - tracks registration metadata.
 */
export interface RegisteredTool {
  /** The tool definition (with JSON Schema, not Zod) */
  definition: ToolDefinition;

  /** The handler function */
  handler: ToolHandler;

  /** Per-broker network targeting (empty = all brokers, all networks) */
  brokerNetworks: Record<string, { networks: string[] }>;
}

/**
 * Internal bridge interface for transports to execute tools.
 *
 * This is NOT exposed to users - only used internally by native/stdio/broker
 * transports to invoke tools registered on a KadiClient.
 *
 * @internal
 */
export interface ToolExecutionBridge {
  /**
   * Execute a tool registered on this client.
   * @internal
   */
  executeToolHandler(
    toolName: string,
    params: unknown,
    context?: RequestContext
  ): Promise<unknown>;

  /**
   * Get all registered tool definitions.
   * @internal
   */
  getRegisteredTools(): ToolDefinition[];
}

// ═══════════════════════════════════════════════════════════════════════
// 3. LOADED ABILITIES
// ═══════════════════════════════════════════════════════════════════════

/**
 * Transport type for loaded abilities.
 * - native: In-process (same Node.js process)
 * - stdio: Child process (JSON-RPC over stdin/stdout)
 * - broker: Remote (via broker WebSocket)
 */
export type TransportType = 'native' | 'stdio' | 'broker';

/**
 * Event handler function type.
 */
export type EventHandler = (data: unknown) => void | Promise<void>;

/**
 * Options for invoking a tool on a loaded ability.
 */
export interface InvokeOptions {
  /**
   * Max time to wait for the remote agent to respond (milliseconds).
   * Overrides the default timeout set when loading the ability.
   *
   * @default Uses timeout from load options, or 600000ms (10 minutes) if not specified.
   *
   * @example
   * ```typescript
   * // Quick operation - short timeout
   * const models = await ability.invoke('list-models', {}, { timeout: 5000 });
   *
   * // Slow LLM inference - longer timeout
   * const result = await ability.invoke('chat-completion', params, { timeout: 600000 });
   * ```
   */
  timeout?: number;
}

export interface LoadedAbility {
  /** Name of the ability */
  readonly name: string;

  /** How this ability is connected */
  readonly transport: TransportType;

  /**
   * Invoke a tool on this ability.
   * This is the main way to call tools.
   *
   * @param toolName - Name of the tool to invoke
   * @param params - Input parameters for the tool
   * @param options - Optional settings (timeout)
   * @returns The tool's output
   *
   * @example
   * ```typescript
   * // Use default timeout
   * const result = await ability.invoke('add', { a: 5, b: 3 });
   *
   * // Override timeout for slow operations
   * const chat = await ability.invoke('chat-completion', params, { timeout: 300000 });
   * ```
   */
  invoke<T = unknown>(toolName: string, params: unknown, options?: InvokeOptions): Promise<T>;

  /**
   * Get list of tools this ability provides.
   * Useful for discovery and debugging.
   */
  getTools(): ToolDefinition[];

  /**
   * Subscribe to events from this ability.
   *
   * @param event - Event name to listen for
   * @param handler - Function called when event fires
   *
   * @example
   * ```typescript
   * ability.on('file.changed', (data) => {
   *   console.log('File changed:', data.path);
   * });
   * ```
   */
  on(event: string, handler: EventHandler): void;

  /**
   * Unsubscribe from events.
   *
   * @param event - Event name to stop listening for
   * @param handler - The handler function to remove
   */
  off(event: string, handler: EventHandler): void;

  /**
   * Disconnect and cleanup.
   * For stdio: kills the child process.
   * For broker: nothing (broker connection managed by client).
   * For native: nothing (shares process).
   */
  disconnect(): Promise<void>;
}

// ═══════════════════════════════════════════════════════════════════════
// 4. CLIENT IDENTITY & BROKER STATE
// ═══════════════════════════════════════════════════════════════════════

/**
 * Client cryptographic identity.
 *
 * Generated once at client construction and used for all broker connections.
 * This ensures consistent identity across multiple brokers.
 *
 * The agentId is deterministically derived from the publicKey using the same
 * algorithm as the broker: SHA256(publicKey).hex().substring(0, 16)
 *
 * @example
 * ```typescript
 * const client = new KadiClient({ name: 'my-agent' });
 *
 * // Identity available immediately (before connect)
 * console.log(client.identity);
 * // { publicKey: 'MIIBIjAN...', agentId: 'a1b2c3d4e5f67890' }
 *
 * console.log(client.publicKey);  // 'MIIBIjAN...'
 * console.log(client.agentId);    // 'a1b2c3d4e5f67890'
 * ```
 */
export interface ClientIdentity {
  /** Base64-encoded Ed25519 public key (SPKI DER format) */
  publicKey: string;

  /** Deterministic agent ID: SHA256(publicKey).hex().substring(0, 16) */
  agentId: string;
}

/**
 * Connection status for a broker.
 *
 * States:
 * - disconnected: Not connected
 * - connecting: Initial connection in progress
 * - connected: Connected and authenticated
 * - disconnecting: User-initiated disconnect in progress
 * - reconnecting: Auto-reconnecting after unexpected disconnect
 */
export type BrokerStatus = 'disconnected' | 'connecting' | 'connected' | 'disconnecting' | 'reconnecting';

/**
 * Internal state for a single broker connection.
 * Managed by KadiClient - not exposed to users.
 *
 * Note: Identity fields (publicKey, privateKey, agentId) are stored at the
 * client level, not per-broker. All broker connections share the same identity.
 */
export interface BrokerState {
  /** Friendly name for this broker (from config) */
  name: string;

  /** WebSocket URL */
  url: string;

  /** Networks this broker connection has joined */
  networks: string[];

  /** WebSocket connection (null if disconnected) */
  ws: WebSocket | null;

  /** Heartbeat timer (null if not running) */
  heartbeatTimer: ReturnType<typeof setInterval> | null;

  /**
   * Pending JSON-RPC requests waiting for responses.
   * Keyed by JSON-RPC message id.
   * Used for: hello, authenticate, register, heartbeat.
   */
  pendingRequests: Map<string | number, PendingRequest>;

  /**
   * Pending tool invocations waiting for result notifications.
   * Keyed by requestId (client-generated UUID).
   * Used for: invokeRemote() async pattern.
   */
  pendingInvocations: Map<string, PendingInvocation>;

  /** Current connection status */
  status: BrokerStatus;

  // ─────────────────────────────────────────────────────────────
  // RECONNECTION STATE
  // ─────────────────────────────────────────────────────────────

  /**
   * True if disconnect was intentional (user called disconnect()).
   * When false, unexpected close triggers auto-reconnect.
   */
  intentionalDisconnect: boolean;

  /**
   * Current reconnection attempt number.
   * Reset to 0 on successful connection.
   */
  reconnectAttempts: number;

  /**
   * Timer for scheduled reconnection attempt.
   * Null when not reconnecting.
   */
  reconnectTimer: ReturnType<typeof setTimeout> | null;

  // ─────────────────────────────────────────────────────────────
  // EVENT SUBSCRIPTIONS
  // ─────────────────────────────────────────────────────────────

  /**
   * Local handlers for each subscribed pattern.
   * Pattern → Set of handler functions.
   *
   * This is CLIENT-SIDE tracking. When we subscribe to 'user.*' on the broker,
   * we store the handlers here so we can dispatch incoming events locally.
   */
  eventHandlers: Map<string, Set<BrokerEventHandler>>;

  /**
   * Patterns that are currently subscribed on the broker.
   * Used to track broker-side subscriptions (separate from local handlers).
   *
   * This exists because multiple handlers can subscribe to the same pattern,
   * but we only need ONE broker subscription per pattern.
   */
  subscribedPatterns: Set<string>;
}

/**
 * A request waiting for a response from the broker.
 * Used for JSON-RPC request/response matching (e.g., hello, auth, register).
 */
export interface PendingRequest {
  /** Resolve the promise with the result */
  resolve: (value: unknown) => void;

  /** Reject the promise with an error */
  reject: (error: Error) => void;

  /** Timeout timer */
  timeout: ReturnType<typeof setTimeout>;

  /** Method name (for error messages) */
  method: string;

  /** When the request was sent */
  sentAt: Date;
}

/**
 * A tool invocation waiting for its result notification.
 *
 * This is separate from PendingRequest because tool invocations use
 * a different async pattern:
 *
 * 1. Client sends kadi.ability.request → broker returns { status: 'pending', requestId }
 * 2. Broker forwards to provider → provider executes → sends result back
 * 3. Broker sends kadi.ability.response notification to client with the result
 *
 * The key is requestId (from step 1), not the JSON-RPC message id.
 */
export interface PendingInvocation {
  /** Resolve the promise with the tool result */
  resolve: (value: unknown) => void;

  /** Reject the promise with an error */
  reject: (error: Error) => void;

  /** Timeout timer */
  timeout: ReturnType<typeof setTimeout>;

  /** Tool name (for error messages) */
  toolName: string;

  /** When the invocation was sent */
  sentAt: Date;
}

// ═══════════════════════════════════════════════════════════════════════
// 5. JSON-RPC
// ═══════════════════════════════════════════════════════════════════════

/**
 * JSON-RPC 2.0 request message.
 * Used for communication with broker and stdio abilities.
 */
export interface JsonRpcRequest {
  jsonrpc: '2.0';
  id: string | number;
  method: string;
  params?: unknown;
}

/**
 * JSON-RPC 2.0 response message.
 */
export interface JsonRpcResponse {
  jsonrpc: '2.0';
  id: string | number;
  result?: unknown;
  error?: JsonRpcError;
}

/**
 * JSON-RPC 2.0 notification (no id, no response expected).
 */
export interface JsonRpcNotification {
  jsonrpc: '2.0';
  method: string;
  params?: unknown;
}

/**
 * JSON-RPC 2.0 error object.
 */
export interface JsonRpcError {
  code: number;
  message: string;
  data?: unknown;
}

/**
 * Any JSON-RPC 2.0 message (request, response, or notification).
 * Useful when parsing incoming messages that could be any type.
 */
export type JsonRpcMessage = JsonRpcRequest | JsonRpcResponse | JsonRpcNotification;

// ═══════════════════════════════════════════════════════════════════════
// 6. LOCK FILE (from kadi-install)
// ═══════════════════════════════════════════════════════════════════════

/**
 * Structure of agent-lock.json file.
 * Generated by kadi-install, consumed by kadi-core for ability resolution.
 */
export interface AgentLockFile {
  /** Lock file format version */
  lockfileVersion: number;

  /** Metadata about when/how this was generated */
  metadata: {
    /** ISO 8601 timestamp of generation */
    generated: string;

    /** SHA256 hash of agent.json abilities section (for change detection) */
    metaHash: string;

    /** KADI version that created this lock file */
    kadiVersion?: string;
  };

  /** Info about the agent this lock file belongs to */
  agent?: {
    name: string;
    version: string;
  };

  /** Map of installed abilities (key format: "name@version") */
  abilities: Record<string, AbilityLockEntry>;
}

/**
 * Entry for a single ability in the lock file.
 */
export interface AbilityLockEntry {
  /** Exact installed version */
  version: string;

  /** Type of package */
  type: 'ability' | 'plugin' | 'agent';

  /** Path where installed (relative to project root) */
  resolved: string;

  /** SHA512 integrity hash of installed files */
  integrity: string;

  /** Whether this is a direct dependency (vs transitive) */
  isTopLevel: boolean;

  /** Original version constraint from agent.json (e.g., "^1.0.0") */
  requestedVersion?: string;

  /** Dependencies of this ability */
  dependencies?: Record<string, string>;

  /** Which abilities depend on this one */
  requiredBy?: string[];

  /** Registry URL where this was downloaded from */
  source?: string;

  /** Entry point file (from ability's agent.json entrypoint field) */
  entrypoint?: string;
}

// ═══════════════════════════════════════════════════════════════════════
// 7. UTILITY TYPES
// ═══════════════════════════════════════════════════════════════════════

/**
 * Options for registerTool().
 */
export interface RegisterToolOptions {
  /**
   * Per-broker network scoping.
   * Keys are broker names, values specify which networks to register on for that broker.
   * Each broker name must exist in client's configured brokers.
   * Each network list must be a subset of that specific broker's networks.
   * If not specified, registers with ALL brokers on ALL their networks.
   *
   * @example
   * ```typescript
   * client.registerTool(def, handler, {
   *   brokers: {
   *     local: { networks: ['private'] },
   *     remote: { networks: ['sensitive'] },
   *   },
   * });
   * ```
   */
  brokers?: Record<string, { networks: string[] }>;
}

/**
 * Base options for loading abilities.
 * Extended by LoadNativeOptions, LoadStdioOptions, and LoadBrokerOptions.
 */
export interface LoadOptions {
  /**
   * Default timeout for all invocations on this ability (milliseconds).
   * Can be overridden per-call in invoke().
   *
   * @default 600000 (10 minutes)
   *
   * @example
   * ```typescript
   * // Set 5-minute default for this ability
   * const mm = await client.loadBroker('model-manager', { timeout: 300000 });
   *
   * // All invokes use 300000 unless overridden
   * await mm.invoke('chat-completion', params);
   *
   * // Override for quick operation
   * await mm.invoke('list-models', {}, { timeout: 5000 });
   * ```
   */
  timeout?: number;
}

/**
 * Options for loadNative().
 */
export interface LoadNativeOptions extends LoadOptions {
  /**
   * Explicit path to the ability.
   * If not provided, resolves from agent-lock.json.
   */
  path?: string;

  /**
   * Project root for lock file resolution.
   * Only used when `path` is not provided.
   * Default: auto-detected by walking up from current directory.
   */
  projectRoot?: string;
}

/**
 * Options for loadStdio().
 *
 * Three modes of operation:
 *
 * 1. **Explicit mode** — Provide `command` and `args` directly:
 *    ```typescript
 *    loadStdio('analyzer', { command: 'python3', args: ['./main.py'] })
 *    ```
 *
 * 2. **Script selection mode** — Choose which script from ability's agent.json:
 *    ```typescript
 *    loadStdio('analyzer', { script: 'dev' })  // Uses scripts.dev
 *    ```
 *
 * 3. **Default mode** — Uses scripts.start from ability's agent.json:
 *    ```typescript
 *    loadStdio('analyzer')  // Uses scripts.start
 *    ```
 *
 * **Priority**: If `command` is provided, `script` is ignored (explicit mode wins).
 */
export interface LoadStdioOptions extends LoadOptions {
  /**
   * Explicit command to run.
   * If provided, bypasses agent.json lookup entirely.
   */
  command?: string;

  /**
   * Arguments to pass to the command.
   * Only used when `command` is provided.
   */
  args?: string[];

  /**
   * Which script to use from the ability's agent.json scripts section.
   * Only used when `command` is not provided.
   * Default: 'start'
   *
   * @example
   * If ability's agent.json has:
   * ```json
   * { "scripts": { "start": "python3 main.py", "dev": "python3 main.py --debug" } }
   * ```
   * Then `{ script: 'dev' }` will run: `python3 main.py --debug`
   */
  script?: string;

  /**
   * Project root for lock file resolution.
   * Only used when `command` is not provided.
   * Default: auto-detected by walking up from current directory.
   */
  projectRoot?: string;
}

/**
 * Resolved script ready for spawning a child process.
 * Returned by resolveAbilityScript() after parsing an ability's agent.json.
 */
export interface ResolvedScript {
  /** The command to execute (e.g., 'python3', 'npx') */
  command: string;

  /** Arguments to pass to the command (e.g., ['main.py', '--debug']) */
  args: string[];

  /** Working directory for the child process (the ability's directory) */
  cwd: string;
}

/**
 * Options for loadBroker().
 */
export interface LoadBrokerOptions extends LoadOptions {
  /**
   * Which broker to use.
   * If not provided, uses defaultBroker from config.
   */
  broker?: string;

  /**
   * Networks to filter by when discovering the ability.
   */
  networks?: string[];
}

/**
 * Options for invokeRemote().
 */
export interface InvokeRemoteOptions {
  /**
   * Which broker to send the request to.
   *
   * Use this when connected to multiple brokers and you want to route
   * the request through a specific one.
   *
   * @default The `defaultBroker` from your KadiClient constructor, or the first broker if not specified.
   *
   * @example
   * ```typescript
   * // Route through the 'internal' broker instead of the default
   * await client.invokeRemote('analyze', data, { broker: 'internal' });
   * ```
   */
  broker?: string;

  /**
   * Max time to wait for the remote agent to respond before giving up.
   *
   * When the timeout is reached, the promise rejects with a `BROKER_TIMEOUT` error.
   * The remote agent may still be processing - this only affects how long YOU wait.
   *
   * @default 600000 (10 minutes) - from `requestTimeout` in your KadiClient constructor options.
   *
   * @example
   * ```typescript
   * // Quick timeout for health checks
   * await client.invokeRemote('ping', {}, { timeout: 5000 });
   * ```
   */
  timeout?: number;
}

// ═══════════════════════════════════════════════════════════════════════
// 8. BROKER EVENTS (Pub/Sub)
// ═══════════════════════════════════════════════════════════════════════

/**
 * An event received from the broker's pub/sub system.
 *
 * When you subscribe to a pattern (e.g., 'user.*'), you receive BrokerEvent
 * objects for each matching event published by any agent in the network.
 *
 * @example
 * ```typescript
 * client.subscribe('user.*', (event: BrokerEvent) => {
 *   console.log(event.channel);    // 'user.login'
 *   console.log(event.data);       // { userId: '123' }
 *   console.log(event.networkId);  // 'global'
 *   console.log(event.source);     // Publisher's session ID
 * });
 * ```
 */
export interface BrokerEvent {
  /**
   * The channel/topic this event was published to.
   * This is the exact channel name (e.g., 'user.login'), not the pattern
   * you subscribed to (e.g., 'user.*').
   */
  channel: string;

  /**
   * The event payload.
   * Can be any JSON-serializable data the publisher sent.
   */
  data: unknown;

  /**
   * Which network this event was published to.
   * Events are scoped to networks - you only receive events from
   * networks you're a member of.
   */
  networkId: string;

  /**
   * Session ID of the agent that published this event.
   * Useful for filtering out your own events or identifying the source.
   */
  source: string;

  /**
   * Unix timestamp (milliseconds) when the event was published.
   */
  timestamp: number;
}

/**
 * Handler function for broker events.
 *
 * @example
 * ```typescript
 * const handler: BrokerEventHandler = (event) => {
 *   console.log(`Received ${event.channel} from ${event.source}`);
 * };
 * client.subscribe('chat.*', handler);
 * ```
 */
export type BrokerEventHandler = (event: BrokerEvent) => void | Promise<void>;

/**
 * Options for publishing events via the broker.
 */
export interface PublishOptions {
  /**
   * Which network to publish to.
   * You must be a member of this network to publish to it.
   *
   * If not specified:
   * - Uses the first network from your config.networks array
   * - If you have no networks configured, uses 'global'
   *
   * @example
   * ```typescript
   * // Publish to specific network
   * await client.publish('order.created', data, { network: 'internal' });
   *
   * // Publish to default network
   * await client.publish('order.created', data);
   * ```
   */
  network?: string;

  /**
   * Which broker to publish through.
   * If not specified, uses defaultBroker from config.
   */
  broker?: string;
}

/**
 * Options for subscribing to broker events.
 */
export interface SubscribeOptions {
  /**
   * Which broker to subscribe through.
   * If not specified, uses defaultBroker from config.
   *
   * Note: Subscriptions apply to ALL networks you're a member of on that broker.
   * You cannot subscribe to only specific networks - network filtering is done
   * at the broker level based on your session's network membership.
   */
  broker?: string;
}

/**
 * Options for emitting events.
 */
export interface EmitOptions {
  /**
   * Broker to also publish this event to.
   *
   * If specified, the event is emitted locally (to parent agent) AND
   * published to all subscribers on the specified broker.
   *
   * @example
   * ```typescript
   * // Local only (default)
   * client.emit('progress', { percent: 50 });
   *
   * // Local AND broadcast to broker subscribers
   * client.emit('order.created', orderData, { broker: 'local' });
   * ```
   */
  broker?: string;

  /**
   * Network to publish to (only used when broker is specified).
   * Defaults to the first network in config.networks, or 'global'.
   */
  network?: string;
}
