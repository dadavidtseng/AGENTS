/**
 * KADI Protocol Message Builders
 * ==============================
 *
 * Pure functions that construct JSON-RPC 2.0 message objects for the KADI protocol.
 *
 * All functions return typed objects ready for `JSON.stringify()`.
 *
 * @example
 * ```typescript
 * import * as protocol from './protocol.js';
 *
 * const msg = protocol.heartbeat(1);
 * ws.send(JSON.stringify(msg));
 * ```
 *
 * Python Equivalent:
 *   kadi-core-py/src/kadi/protocol.py
 */

import type { JsonRpcNotification, JsonRpcRequest, JsonRpcResponse } from './types.js';

// ---------------------------------------------------------------------------
// Generic request builder
// ---------------------------------------------------------------------------

/** Build a standard JSON-RPC 2.0 request. */
export function request(id: string | number, method: string, params: unknown): JsonRpcRequest {
  return { jsonrpc: '2.0', id, method, params };
}

// ===========================================================================
// Session
// ===========================================================================

/** Build a `kadi.session.hello` request. */
export function hello(id: number): JsonRpcRequest {
  return request(id, 'kadi.session.hello', { role: 'agent' });
}

/** Build a `kadi.session.authenticate` request. */
export function authenticate(
  id: number,
  publicKey: string,
  signature: string,
  nonce: string,
): JsonRpcRequest {
  return request(id, 'kadi.session.authenticate', { publicKey, signature, nonce });
}

/** Build a `kadi.session.heartbeat` request. */
export function heartbeat(id: number): JsonRpcRequest {
  return request(id, 'kadi.session.heartbeat', { timestamp: Date.now() });
}

// ===========================================================================
// Agent
// ===========================================================================

/** Build a `kadi.agent.register` request. */
export function register(
  id: number,
  tools: unknown[],
  networks: string[],
  displayName?: string,
): JsonRpcRequest {
  const params: Record<string, unknown> = { tools, networks };
  if (displayName !== undefined) {
    params.displayName = displayName;
  }
  return request(id, 'kadi.agent.register', params);
}

// ===========================================================================
// Ability
// ===========================================================================

/** Build a `kadi.ability.request` request. */
export function abilityRequest(
  id: number,
  toolName: string,
  toolInput: unknown,
  requestId: string,
  timeout?: number,
): JsonRpcRequest {
  const params: Record<string, unknown> = { toolName, toolInput, requestId };
  if (timeout !== undefined) {
    params.timeout = timeout;
  }
  return request(id, 'kadi.ability.request', params);
}

/** Build a `kadi.ability.list` request. */
export function abilityList(
  id: number,
  networks: string[],
  includeProviders = true,
): JsonRpcRequest {
  return request(id, 'kadi.ability.list', { networks, includeProviders });
}

// ===========================================================================
// Event
// ===========================================================================

/** Build a `kadi.event.subscribe` request. */
export function eventSubscribe(id: number, pattern: string): JsonRpcRequest {
  return request(id, 'kadi.event.subscribe', { pattern });
}

/** Build a `kadi.event.unsubscribe` request. */
export function eventUnsubscribe(id: number, pattern: string): JsonRpcRequest {
  return request(id, 'kadi.event.unsubscribe', { pattern });
}

/** Build a `kadi.event.publish` request. */
export function eventPublish(
  id: number,
  channel: string,
  data: unknown,
  networkId: string,
): JsonRpcRequest {
  return request(id, 'kadi.event.publish', { channel, data, networkId });
}

// ===========================================================================
// Response (JSON-RPC result/error envelopes)
// ===========================================================================

/** Build a JSON-RPC 2.0 success response. */
export function resultResponse(id: string | number, result: unknown): JsonRpcResponse {
  return { jsonrpc: '2.0', id, result };
}

/** Build a JSON-RPC 2.0 error response. */
export function errorResponse(
  id: string | number,
  code: number,
  message: string,
  data?: unknown,
): JsonRpcResponse {
  const error: { code: number; message: string; data?: unknown } = { code, message };
  if (data !== undefined) {
    error.data = data;
  }
  return { jsonrpc: '2.0', id, error };
}

// ===========================================================================
// Stdio
// ===========================================================================

/** Build a `readAgentJson` request for stdio transport. */
export function readAgentJson(id: number): JsonRpcRequest {
  return request(id, 'readAgentJson', {});
}

/** Build an `event` notification (no `id` field). */
export function eventNotification(name: string, data: unknown): JsonRpcNotification {
  return { jsonrpc: '2.0', method: 'event', params: { name, data } };
}
