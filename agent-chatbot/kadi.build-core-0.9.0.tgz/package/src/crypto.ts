/**
 * Cryptographic utilities for KADI
 *
 * This module provides utilities for converting between Ed25519 signing keys
 * and X25519 encryption keys.
 *
 * ## Background
 *
 * KADI uses Ed25519 keys for identity and authentication (signing).
 * However, Ed25519 is a signing algorithm - it cannot encrypt data.
 *
 * X25519 is an encryption algorithm that allows:
 * - Encrypting data so only the recipient can read it
 * - Sealed boxes: sender encrypts with recipient's public key,
 *   only recipient's private key can decrypt
 *
 * Both algorithms use Curve25519 underneath, so an Ed25519 key
 * can be mathematically converted to an X25519 key.
 *
 * @module crypto
 */

// @ts-expect-error - ed2curve doesn't have type definitions
import ed2curve from 'ed2curve';

/**
 * X25519 encryption key pair.
 *
 * Used for public-key encryption (e.g., sealed boxes).
 * Derived from Ed25519 signing keys.
 */
export interface EncryptionKeyPair {
  /** X25519 public key (32 bytes) - share with others to receive encrypted messages */
  publicKey: Uint8Array;
  /** X25519 secret key (32 bytes) - keep private, used to decrypt messages */
  secretKey: Uint8Array;
}

/**
 * Convert an Ed25519 signing public key to an X25519 encryption public key.
 *
 * KADI uses Ed25519 keys for identity and authentication (signing).
 * However, Ed25519 is a signing algorithm - it cannot encrypt data.
 *
 * X25519 is an encryption algorithm that allows:
 * - Encrypting data so only the recipient can read it
 * - Sealed boxes: sender encrypts with recipient's public key,
 *   only recipient's private key can decrypt
 *
 * Both algorithms use Curve25519 underneath, so an Ed25519 key
 * can be mathematically converted to an X25519 key. This function
 * performs that conversion.
 *
 * @param publicKey - Base64-encoded Ed25519 public key (SPKI DER format)
 * @returns X25519 public key as Uint8Array (32 bytes)
 * @throws Error if the public key is invalid
 *
 * @example
 * ```typescript
 * import { convertToEncryptionKey } from '@kadi.build/core';
 * import nacl from 'tweetnacl';
 *
 * // Convert agent's Ed25519 public key to X25519
 * const encryptionKey = convertToEncryptionKey(agentPublicKey);
 *
 * // Now you can encrypt data for that agent using sealed box
 * const encrypted = nacl.sealedbox.seal(message, encryptionKey);
 * ```
 */
export function convertToEncryptionKey(publicKey: string): Uint8Array {
  // Decode base64 SPKI DER format to raw bytes
  const derBytes = Buffer.from(publicKey, 'base64');

  // SPKI DER format for Ed25519 has a 12-byte header, raw key starts at offset 12
  // Format: 30 2a 30 05 06 03 2b 65 70 03 21 00 [32-byte key]
  const rawEd25519Key = derBytes.slice(12);

  if (rawEd25519Key.length !== 32) {
    throw new Error(
      `Invalid Ed25519 public key: expected 32 bytes after SPKI header, got ${rawEd25519Key.length}`
    );
  }

  // Convert Ed25519 public key to X25519 public key
  const x25519Key = ed2curve.convertPublicKey(new Uint8Array(rawEd25519Key));

  if (!x25519Key) {
    throw new Error('Failed to convert Ed25519 public key to X25519');
  }

  return x25519Key;
}

/**
 * Convert an Ed25519 signing key pair to an X25519 encryption key pair.
 *
 * This is used internally by KadiClient to derive encryption keys from
 * its Ed25519 identity. The resulting key pair can be used with
 * tweetnacl's box or sealedbox functions.
 *
 * @param privateKey - Ed25519 private key in PKCS8 DER format (Buffer)
 * @param publicKey - Base64-encoded Ed25519 public key (SPKI DER format)
 * @returns X25519 key pair for encryption/decryption
 * @throws Error if the keys are invalid
 *
 * @example
 * ```typescript
 * // Inside KadiClient
 * const keyPair = convertToEncryptionKeyPair(this._privateKey, this._publicKeyBase64);
 *
 * // Decrypt a sealed box message
 * const decrypted = nacl.sealedbox.open(encrypted, keyPair.publicKey, keyPair.secretKey);
 * ```
 */
export function convertToEncryptionKeyPair(
  privateKey: Buffer,
  publicKey: string
): EncryptionKeyPair {
  // Get X25519 public key
  const x25519PublicKey = convertToEncryptionKey(publicKey);

  // PKCS8 DER format for Ed25519 has a header, raw key is at offset 16
  // Format: 30 2e 02 01 00 30 05 06 03 2b 65 70 04 22 04 20 [32-byte seed]
  // The seed is the first 32 bytes of the 64-byte Ed25519 secret key
  const rawSeed = privateKey.slice(16, 48);

  if (rawSeed.length !== 32) {
    throw new Error(
      `Invalid Ed25519 private key: expected 32-byte seed after PKCS8 header, got ${rawSeed.length}`
    );
  }

  // Convert Ed25519 secret key (seed) to X25519 secret key
  // ed2curve.convertSecretKey expects the 64-byte secret key, but we only have the seed
  // We need to expand the seed first by creating the full 64-byte key
  // The full Ed25519 secret key is: seed (32 bytes) + public key (32 bytes)
  const derBytes = Buffer.from(publicKey, 'base64');
  const rawPublicKey = derBytes.slice(12);
  const fullSecretKey = new Uint8Array(64);
  fullSecretKey.set(rawSeed, 0);
  fullSecretKey.set(rawPublicKey, 32);

  const x25519SecretKey = ed2curve.convertSecretKey(fullSecretKey);

  if (!x25519SecretKey) {
    throw new Error('Failed to convert Ed25519 secret key to X25519');
  }

  return {
    publicKey: x25519PublicKey,
    secretKey: x25519SecretKey,
  };
}
