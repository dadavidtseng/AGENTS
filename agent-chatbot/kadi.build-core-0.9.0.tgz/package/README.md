# kadi-core

TypeScript SDK for building KADI agents. Register tools, connect to brokers, load abilities, publish events.

kadi-core lets you:
- **Expose functions** as callable tools over the network
- **Discover and invoke** remote services without hardcoding URLs
- **Communicate via events** across your service mesh

## Install

```bash
npm install @kadi.build/core
```

**Requirements:**
- Node.js 18+
- TypeScript 5.0+ (recommended for full type inference)
- ESM only (`"type": "module"` in your package.json)

## Quick Start

Create a simple calculator agent:

```typescript
// calculator.ts
import { KadiClient, z } from '@kadi.build/core';

const client = new KadiClient({
  name: 'calculator',
  version: '1.0.0',
});

client.registerTool({
  name: 'add',
  description: 'Add two numbers',
  input: z.object({ a: z.number(), b: z.number() }),
}, async ({ a, b }) => ({ result: a + b }));

// Start listening for requests over stdio
await client.serve('stdio');
```

Now another agent can load and use it:

---

## Table of Contents

- [Core Concepts](#core-concepts)
- [Registering Tools](#registering-tools)
- [Connecting to Brokers](#connecting-to-brokers)
- [Loading Abilities](#loading-abilities)
- [Events from Abilities](#events-from-abilities)
- [Broker Events (Pub/Sub)](#broker-events-pubsub)
- [Serving as an Ability](#serving-as-an-ability)
- [Error Handling](#error-handling)
- [API Reference](#api-reference)
- [Troubleshooting](#troubleshooting)

---

## Core Concepts

| Concept | Plain English |
|---------|---------------|
| **Tool** | A function other services can call over the network (like an API endpoint) |
| **Agent** | Your service. One codebase = one agent. Agents expose tools and call other agents' tools. |
| **Broker** | The router/registry. Agents register with brokers so they can find each other (like DNS + API gateway combined) |
| **Ability** | A tool provider you connect to. Could be in-process, a subprocess, or a remote service. |
| **Event** | Fire-and-forget notification. Publish events, other agents can subscribe. |

---

## Registering Tools

Tools are functions you expose for other agents to call.

```typescript
import { KadiClient, z } from '@kadi.build/core';

const client = new KadiClient({ name: 'weather-service' });

// Define input schema with Zod
const weatherInput = z.object({
  city: z.string().describe('City name'),
  units: z.enum(['celsius', 'fahrenheit']).default('celsius'),
});

// Register tool
client.registerTool({
  name: 'getWeather',
  description: 'Get current weather for a city',
  input: weatherInput,
}, async ({ city, units }) => {
  const temp = await fetchTemperature(city);
  return { city, temperature: temp, units };
});
```

**Why Zod?** Type-safe schemas, 70% less code than JSON Schema, automatic TypeScript inference.

### Targeting Specific Brokers

```typescript
// Register tool only on specific brokers
client.registerTool(definition, handler, { brokers: ['internal'] });
```

### Targeting Specific Networks

By default, a tool is visible on **all networks** the agent has joined. You can restrict a tool to specific networks using the `networks` option — the tool will only be discoverable and invocable by agents on those networks.

```typescript
const client = new KadiClient({
  name: 'multi-network-agent',
  brokers: { default: 'ws://localhost:8080/kadi' },
  networks: ['global', 'internal', 'gpu-cluster'],
});

// Visible on ALL agent networks (global, internal, gpu-cluster)
client.registerTool({
  name: 'echo',
  description: 'Echo back the input',
  input: z.object({ message: z.string() }),
}, async ({ message }) => ({ echo: message }));

// Visible ONLY on gpu-cluster
client.registerTool({
  name: 'gpu-inference',
  description: 'Run ML inference on GPU',
  input: z.object({ model: z.string(), prompt: z.string() }),
}, async ({ model, prompt }) => {
  return { result: await runInference(model, prompt) };
}, { networks: ['gpu-cluster'] });

// Visible on internal AND global only (not gpu-cluster)
client.registerTool({
  name: 'audit-log',
  description: 'Retrieve audit logs',
  input: z.object({ limit: z.number() }),
}, async ({ limit }) => {
  return { logs: await getAuditLogs(limit) };
}, { networks: ['internal', 'global'] });
```

Per-tool networks must be a **subset** of the client's `networks`. Attempting to scope a tool to a network the agent hasn't joined throws an `INVALID_CONFIG` error:

```typescript
// Throws KadiError — 'finance' is not in client networks
client.registerTool(definition, handler, { networks: ['finance'] });
```

You can combine `brokers` and `networks` to control both which brokers a tool registers with and which networks it's visible on:

```typescript
client.registerTool(definition, handler, {
  brokers: ['production'],
  networks: ['internal'],
});
```

---

## Connecting to Brokers

Brokers let agents discover and call each other without knowing URLs.

```typescript
const client = new KadiClient({
  name: 'my-agent',
  brokers: {
    default: 'ws://localhost:8080/kadi',
    production: 'wss://broker.example.com/kadi',
  },
  defaultBroker: 'default',
  networks: ['global'],  // Which networks to join
});

// Connect (uses Ed25519 authentication)
await client.connect();

// Invoke a tool - broker routes to any available provider
const result = await client.invokeRemote('add', { a: 5, b: 3 });

// Disconnect when done
await client.disconnect();
```

### Reconnection

Auto-reconnects with exponential backoff (1s → 2s → 4s → ... → 30s max) with jitter:

```typescript
const client = new KadiClient({
  name: 'resilient-agent',
  brokers: { default: 'ws://localhost:8080/kadi' },
  autoReconnect: true,        // Default: true
  maxReconnectDelay: 30000,   // Cap at 30 seconds
});
```

---

## Loading Abilities

Three ways to connect to other agents:

| Method | Use When | How It Works |
|--------|----------|--------------|
| `loadNative(name)` | Ability is a local TypeScript/JavaScript module | Runs in your process |
| `loadStdio(name)` | Ability runs as a separate process (any language) | JSON-RPC over stdin/stdout |
| `loadBroker(name)` | Ability is a remote service | WebSocket via broker |

### loadNative — In-Process

```typescript
// Resolves path from agent-lock.json
const calc = await client.loadNative('calculator');

// Or specify path directly
const calc = await client.loadNative('calculator', { path: './abilities/calc' });

// Use it
const result = await calc.invoke('add', { a: 5, b: 3 });
console.log(result); // { result: 8 }

// Cleanup (no-op for native, but good practice)
await calc.disconnect();
```

### loadStdio — Child Process

By default, launches the ability using `scripts.start` from the ability's `agent.json`:

```typescript
// Runs scripts.start from ability's agent.json
const processor = await client.loadStdio('image-processor');

// Use it
const result = await processor.invoke('resize', { width: 800 });
console.log(result);

// Cleanup (terminates child process)
await processor.disconnect();
```

You can specify a different script to launch:

```typescript
// Run scripts.dev instead of scripts.start
const processor = await client.loadStdio('image-processor', { script: 'dev' });
```

Or bypass `agent.json` entirely with an explicit command:

```typescript
// Explicit command (ignores agent.json)
const processor = await client.loadStdio('processor', {
  command: 'python3',
  args: ['main.py'],
});
```

### loadBroker — Remote via Broker

```typescript
// Must be connected to broker first
await client.connect();

// Find and connect to a remote ability
const gpu = await client.loadBroker('gpu-service', {
  networks: ['gpu-cluster'],
});

const result = await gpu.invoke('inference', { model: 'llama3' });
await gpu.disconnect();
```

---

## Events from Abilities

Abilities can emit real-time events. Subscribe with `on()`, unsubscribe with `off()`.

```typescript
const watcher = await client.loadStdio('file-watcher');

// Define handlers (need references to unsubscribe later)
const onFileChanged = (data) => {
  console.log('File changed:', data.path, data.action);
};

const onError = (data) => {
  console.error('Watch error:', data.message);
};

// Subscribe to events
watcher.on('file.changed', onFileChanged);
watcher.on('file.error', onError);

// Later, unsubscribe
watcher.off('file.changed', onFileChanged);

// Cleanup (terminates child process)
await watcher.disconnect();
```

### Emitting Events (from inside an ability)

If you're building an ability that emits events:

```typescript
// Inside your ability code
client.emit('job.progress', { percent: 50, message: 'Halfway done' });
client.emit('file.changed', { path: '/tmp/foo.txt', action: 'modified' });
```

---

## Broker Events (Pub/Sub)

When connected to a broker, agents can publish and subscribe to events across the network.

### Subscribing

```typescript
await client.connect();

// Subscribe to patterns (RabbitMQ topic exchange style)
client.subscribe('user.*', (event) => {
  console.log(`Channel: ${event.channel}`);   // 'user.login'
  console.log(`Data:`, event.data);           // { userId: '123' }
  console.log(`Network: ${event.networkId}`); // 'global'
  console.log(`Source: ${event.source}`);     // Publisher's session ID
});
```

**Pattern matching:**
- `user.*` → matches `user.login`, `user.logout` (exactly one word after dot)
- `user.#` → matches `user`, `user.login`, `user.profile.update` (zero or more words)
- `order.new` → matches exactly `order.new`

### Publishing

```typescript
// Publish to default network
await client.publish('user.login', { userId: '123', timestamp: Date.now() });

// Publish to specific network
await client.publish('order.created', orderData, { network: 'internal' });
```

### Unsubscribing

```typescript
const handler = (event) => console.log(event);
client.subscribe('user.*', handler);

// Later, remove this specific handler
client.unsubscribe('user.*', handler);
```

---

## Serving as an Ability

To make your agent callable by others:

### Stdio Mode (for loadStdio)

```typescript
const client = new KadiClient({ name: 'my-ability' });

client.registerTool({
  name: 'process',
  description: 'Process data',
  input: z.object({ data: z.string() }),
}, async ({ data }) => {
  return { processed: data.toUpperCase() };
});

// Serve over stdio - blocks until SIGTERM/SIGINT
await client.serve('stdio');
```

### Broker Mode (for loadBroker)

```typescript
const client = new KadiClient({
  name: 'my-service',
  brokers: { default: 'ws://localhost:8080/kadi' },
});

client.registerTool({ /* ... */ }, handler);

// Connect to broker and wait for requests
await client.serve('broker');
```

---

## Error Handling

All errors are `KadiError` with structured codes and context:

```typescript
import { KadiError } from '@kadi.build/core';

try {
  await client.invokeRemote('unknown-tool', {});
} catch (error) {
  if (KadiError.isKadiError(error)) {
    console.log(error.code);      // 'TOOL_NOT_FOUND'
    console.log(error.message);   // Human-readable message
    console.log(error.context);   // { toolName: '...', hint: '...' }
  }
}
```

### Error Codes

| Code | When It Happens |
|------|-----------------|
| `TOOL_NOT_FOUND` | `invoke()` or `invokeRemote()` with unknown tool name |
| `BROKER_NOT_CONNECTED` | Any broker operation before calling `connect()` |
| `ABILITY_NOT_FOUND` | `loadNative/loadStdio` when ability not in agent-lock.json |
| `ABILITY_LOAD_FAILED` | Ability exists but failed to start or initialize |
| `TOOL_INVOCATION_FAILED` | Tool threw an error during execution |
| `BROKER_TIMEOUT` | Request to broker timed out |
| `INVALID_CONFIG` | Configuration error (missing required fields, etc.) |
| `LOCKFILE_NOT_FOUND` | `loadNative/loadStdio` when agent-lock.json doesn't exist |

---

## API Reference

### KadiClient

```typescript
new KadiClient(config: ClientConfig)
```

**Configuration:**

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `name` | `string` | required | Agent name |
| `version` | `string` | `'1.0.0'` | Agent version |
| `brokers` | `Record<string, string>` | `{}` | Broker name → URL map |
| `defaultBroker` | `string` | first broker | Default broker to use |
| `networks` | `string[]` | `['global']` | Networks to join |
| `autoReconnect` | `boolean` | `true` | Auto-reconnect on disconnect |
| `maxReconnectDelay` | `number` | `30000` | Max backoff delay (ms) |
| `requestTimeout` | `number` | `30000` | Default request timeout (ms) |

**Methods:**

| Method | Description |
|--------|-------------|
| `registerTool(def, handler, options?)` | Register a tool. See [Registering Tools](#registering-tools) |
| `connect(broker?)` | Connect to broker |
| `disconnect(broker?)` | Disconnect from broker |
| `invokeRemote(tool, params, options?)` | Invoke tool via broker (broker picks provider) |
| `loadNative(name, options?)` | Load ability in-process. See [Loading Abilities](#loading-abilities) |
| `loadStdio(name, options?)` | Load ability as child process |
| `loadBroker(name, options?)` | Load ability via broker |
| `subscribe(pattern, handler, options?)` | Subscribe to broker events. See [Broker Events](#broker-events-pubsub) |
| `unsubscribe(pattern, handler, options?)` | Unsubscribe from events |
| `publish(channel, data, options?)` | Publish event to broker |
| `emit(event, data)` | Emit event to consumer (when serving as ability) |
| `serve(mode)` | Serve as ability (`'stdio'` or `'broker'`) |
| `getConnectedBrokers()` | List connected broker names |

### LoadedAbility

Returned by `loadNative()`, `loadStdio()`, `loadBroker()`:

| Property/Method | Description |
|-----------------|-------------|
| `name` | Ability name |
| `transport` | `'native'` \| `'stdio'` \| `'broker'` |
| `invoke(tool, params)` | Invoke a tool |
| `getTools()` | Get array of tool definitions |
| `on(event, handler)` | Subscribe to events |
| `off(event, handler)` | Unsubscribe from events |
| `disconnect()` | Cleanup resources |

### BrokerEvent

Received when subscribed to broker events:

```typescript
interface BrokerEvent {
  channel: string;      // 'user.login'
  data: unknown;        // Event payload
  networkId: string;    // Which network
  source: string;       // Publisher's session ID
  timestamp: number;    // Unix timestamp (ms)
}
```

---

## Troubleshooting

### "Cannot find module" with loadNative/loadStdio

The ability isn't in your `agent-lock.json`. Either:
- Run `kadi install` to install abilities and generate the lock file
- Use the `path` option: `loadNative('calc', { path: './path/to/ability' })`
- Use explicit command: `loadStdio('calc', { command: 'node', args: ['calc.js'] })`

### Connection timeout to broker

1. Check the broker is running
2. Verify the URL uses `ws://` or `wss://`, not `http://`
3. Check firewall/network allows WebSocket connections

### Events not being received

1. Verify both publisher and subscriber are on the same network (check `networks` config)
2. Check your pattern matches the channel (remember: `*` = one word, `#` = zero or more)
3. Ensure you're connected before subscribing: `await client.connect()`

### Tool invocation times out

Increase the timeout:
```typescript
await client.invokeRemote('slow-tool', params, { timeout: 60000 });
```

---

## Advanced: Building CLI Tools

These utilities are exported for building tooling on top of kadi-core.

### Zod to JSON Schema

Convert Zod schemas to JSON Schema (useful for generating documentation or OpenAPI specs):

```typescript
import { zodToJsonSchema, z } from '@kadi.build/core';

const schema = z.object({ name: z.string(), age: z.number() });
const jsonSchema = zodToJsonSchema(schema);
// { type: 'object', properties: { name: { type: 'string' }, ... } }
```

### Lock File Resolution

Utilities for working with `agent-lock.json` (the file that tracks installed abilities):

```typescript
import {
  findProjectRoot,
  readLockFile,
  resolveAbilityPath,
  getInstalledAbilityNames,
} from '@kadi.build/core';

// Find the nearest directory containing agent-lock.json
const root = findProjectRoot();

// Read and parse the lock file
const lock = readLockFile(root);

// List installed ability names
const abilities = getInstalledAbilityNames(lock);
// ['calculator', 'image-processor', ...]

// Get the filesystem path to an ability
const calcPath = resolveAbilityPath('calculator', root);
// '/path/to/project/abilities/calculator@1.0.0'
```

---

## Related

- [kadi-core-py](https://gitlab.com/humin-game-lab/kadi/kadi-core-py) — Python SDK (mirrors this API)
- [kadi-broker](https://gitlab.com/humin-game-lab/kadi/kadi-broker) — The broker server

---

## License

MIT
